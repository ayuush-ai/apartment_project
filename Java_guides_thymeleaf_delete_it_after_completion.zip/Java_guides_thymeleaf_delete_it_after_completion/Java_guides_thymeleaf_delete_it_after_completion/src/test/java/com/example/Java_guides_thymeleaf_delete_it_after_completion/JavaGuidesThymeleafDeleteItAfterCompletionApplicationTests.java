package com.example.Java_guides_thymeleaf_delete_it_after_completion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaGuidesThymeleafDeleteItAfterCompletionApplicationTests {

	@Test
	void contextLoads() {
	}

}
