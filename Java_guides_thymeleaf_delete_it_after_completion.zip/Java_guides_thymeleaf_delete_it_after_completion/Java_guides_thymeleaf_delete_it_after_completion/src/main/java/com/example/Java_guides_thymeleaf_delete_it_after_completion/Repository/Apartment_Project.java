package com.example.Java_guides_thymeleaf_delete_it_after_completion.Repository;

import com.example.Java_guides_thymeleaf_delete_it_after_completion.model.Apartment_User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface Apartment_Project extends JpaRepository<Apartment_User,Integer> {



}
