package com.example.Java_guides_thymeleaf_delete_it_after_completion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaGuidesThymeleafDeleteItAfterCompletionApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaGuidesThymeleafDeleteItAfterCompletionApplication.class, args);
	}

}
