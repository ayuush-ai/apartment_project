package com.example.Java_guides_thymeleaf_delete_it_after_completion.Service;

import com.example.Java_guides_thymeleaf_delete_it_after_completion.Repository.Project_work_List_Repository;
import com.example.Java_guides_thymeleaf_delete_it_after_completion.model.Project_work_list;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class Project_Service {


    @Autowired
    private Project_work_List_Repository projectWorkListRepository;

//    public List<Project_work_list> getProjectsCreatedInLast7Hours() {
//        LocalDateTime endTime = LocalDateTime.now();
//        LocalDateTime startTime = endTime.minusHours(7);
//        return projectWorkListRepository.findAllByCreatedAtBetween(startTime, endTime);
//    }

}
