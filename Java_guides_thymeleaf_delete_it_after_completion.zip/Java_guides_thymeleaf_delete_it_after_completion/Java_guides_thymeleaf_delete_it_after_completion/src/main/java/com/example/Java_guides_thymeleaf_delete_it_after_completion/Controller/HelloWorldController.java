package com.example.Java_guides_thymeleaf_delete_it_after_completion.Controller;

import com.example.Java_guides_thymeleaf_delete_it_after_completion.Repository.Apartment_Project;
import com.example.Java_guides_thymeleaf_delete_it_after_completion.Repository.Project_work_List_Repository;
import com.example.Java_guides_thymeleaf_delete_it_after_completion.model.Apartment_User;
import com.example.Java_guides_thymeleaf_delete_it_after_completion.model.Project_work_list;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.time.LocalDateTime;
import java.util.List;

@Controller
public class HelloWorldController {

    @Autowired
    private Apartment_Project apartmentProject;

//    @GetMapping("/get")
//    public String getMap(Model model) {
//        model.addAttribute("message", "Welcome To Apartment project");
//        return "home"; // Ensure you have a home.html template
//    }

    @GetMapping("/get1")
    public String getDetails(Model model) {
        Apartment_User user = new Apartment_User(1, "life is like hell", "401");
        // apartmentProject.save(user); // Uncomment if you want to save this user
        model.addAttribute("user", user);
        return "success"; // Make sure you have a success.html template
    }

    @GetMapping("/get2")
    public String getAllDetails(Model model) {
        List<Apartment_User> users = apartmentProject.findAll();
        model.addAttribute("users", users); // Change to "users" to match Thymeleaf template
        return "apartment_users_list"; // Ensure you have apartment_users_list.html template
    }

//    @GetMapping("/addUser")
//    public String showAddUser_Form(Model model) {
//        model.addAttribute("user", new Apartment_User());
//        return "add_user"; // Name of your form HTML file
//    }
//
//    @PostMapping("/addUser")
//    public String addUser(@ModelAttribute("user") Apartment_User user) {
//        apartmentProject.save(user); // Save the user to the database
//        return "redirect:/get2"; // Redirect to the list of users after saving
//    }


    @Autowired
    private Project_work_List_Repository repo1;

    @GetMapping("/date")
    public String retrieveDate(Model model) {
        // Define the start and end date
        LocalDateTime startDate = LocalDateTime.of(2024, 12, 3, 1, 57, 44);
        LocalDateTime endDate = LocalDateTime.of(2024, 12, 3, 2, 57, 55);

        // Fetch data using the corrected repository method
        List<Project_work_list> dateAndTime = repo1.findByCreatedAtBetween(startDate, endDate);

        // Add the data to the model to pass it to the Thymeleaf template
        model.addAttribute("dateAndTimeList", dateAndTime);

        // Return the name of the Thymeleaf template
        return "practise";
    }






}