package com.example.Java_guides_thymeleaf_delete_it_after_completion.Repository;

import com.example.Java_guides_thymeleaf_delete_it_after_completion.model.Project_User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Project_User_Repository extends JpaRepository<Project_User,Integer> {
}
