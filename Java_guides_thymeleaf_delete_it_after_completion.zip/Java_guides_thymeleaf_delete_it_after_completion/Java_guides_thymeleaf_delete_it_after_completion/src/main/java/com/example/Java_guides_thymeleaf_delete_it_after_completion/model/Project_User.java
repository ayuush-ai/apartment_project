package com.example.Java_guides_thymeleaf_delete_it_after_completion.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Project_User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int apartment_number;
    private String Owner_name;
    private String Owner_Email_adress;



}
